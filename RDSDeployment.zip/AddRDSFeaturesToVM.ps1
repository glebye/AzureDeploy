﻿# Add Features to VM

$vmName = [System.Net.Dns]::GetHostByName((hostname)).HostName

Write-host 'Adding features to VM ' $vmName -foregroundcolor yellow -backgroundcolor red
Add-WindowsFeature –Name RDS-Connection-Broker –IncludeAllSubFeature 
Add-WindowsFeature –Name RDS-Gateway –IncludeAllSubFeature
Add-WindowsFeature –Name RDS-Licensing –IncludeAllSubFeature 
Add-WindowsFeature –Name RDS-Web-Access –IncludeAllSubFeature 
Add-WindowsFeature –Name RDS-RD-Server –IncludeAllSubFeature
Add-WindowsFeature NET-Framework-Core
Add-WindowsFeature Desktop-Experience