﻿# RDS configuration

$ConnectionBroker = $vmName
$WebAccessServer = $vmName
$SessionHost = $vmName
$RDSGateway = $vmName
$RDSLicensing = $vmName
$CollectionName = 'Dustin Solution Operation Collection'
$GatewayExternalFqdn = 'sky.lab1.local'
$RDWorkspaceName = 'Dustin Solution Operation'
$CustomRdpProperty = "use redirection server name:i:1 `n alternate full address:s:sky.lab1.local"

$vmName = [System.Net.Dns]::GetHostByName((hostname)).HostName

Import-Module RemoteDesktop

Write-host 'Configuring new SessionDeployment to VM ' $vmName -foregroundcolor yellow -backgroundcolor red      
New-SessionDeployment -ConnectionBroker $ConnectionBroker -WebAccessServer $WebAccessServer -SessionHost $SessionHost

Write-host 'Configuring new SessionCollection to VM ' $vmName -foregroundcolor yellow -backgroundcolor red      
New-RDSessionCollection -CollectionName $CollectionName -SessionHost $SessionHost -ConnectionBroker $ConnectionBroker

Write-host 'Configuring new RDS-GATEWAY to VM ' $vmName -foregroundcolor yellow -backgroundcolor red      
Add-RDServer -Server $RDSGateway -Role "RDS-GATEWAY" -ConnectionBroker $ConnectionBroker -GatewayExternalFqdn $GatewayExternalFqdn

Write-host 'Configuring new RDS-LICENSING to VM ' $vmName -foregroundcolor yellow -backgroundcolor red      
Add-RDServer -Server $RDSLicensing -Role "RDS-LICENSING" -ConnectionBroker $ConnectionBroker

Write-host 'Setting RDWorkspace to VM ' $RDWorkspaceName -foregroundcolor yellow -backgroundcolor red      
Set-RDWorkspace -Name $RDWorkspaceName 

Write-host 'Configuring RDSessionCollectionConfiguration on VM ' $vmName -foregroundcolor yellow -backgroundcolor red      
Set-RDSessionCollectionConfiguration –CollectionName $CollectionName -CustomRdpProperty $CustomRdpProperty 

Write-host 'RDS configuration completed on VM ' $vmName -foregroundcolor yellow -backgroundcolor red  